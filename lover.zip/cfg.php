<?php
/*
Di isi EC User Id kalian

$EC = 'EC-UserId-123456';

*/



$EC = 'EC-UserId-12XXXX';
